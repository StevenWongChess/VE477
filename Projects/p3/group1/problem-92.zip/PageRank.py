import numpy as np
import random
import matplotlib.pyplot as plt

# randomly generate a netwrok with links from s to t
s = [random.randint(1, 100) for _ in range(1000)]
t = [random.randint(1, 100) for _ in range(1000)]

# genarte the adjacant matrix
dim = max(s + t)
adj = np.zeros([dim, dim])
node = set()
for u, v in zip(s, t):
    if u != v:
        node.update([u,v])
        adj[u-1][v-1] = 1
print("Network with {} nodes and {} edges".format(len(node), np.sum(adj)))

# compute transitional matrix
tran = adj.transpose()
for i in range(dim):
    if sum(tran[:,i]) != 0:
        tran[:,i] = tran[:,i] / sum(tran[:,i])
    else:
        tran[:,i] = 1 / dim 
beta = 0.85     # parameter for teleport
A = beta * tran + (1-beta) * np.ones([dim, dim]) / dim

# power iteration on r
r, r_ = np.ones(dim) / dim, np.ones(dim)
while np.linalg.norm(r-r_) > 1e-6:
    r_ = r
    r = A.dot(r)

for i in range(dim):
    print("Node {}: {}".format(i+1, r[i]))
