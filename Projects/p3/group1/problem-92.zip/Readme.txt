This is a simlpe program for PageRank algorithm used by Google to calculate ranks for web pages. The program randomly generates a graph with about 100 nodes and 1000 egdes and output a 100-dimension rank vector. A jupyter notebook is offerred for clearer demostration.

Created by Yang Xuting from group 9, for VE477 course project 3.