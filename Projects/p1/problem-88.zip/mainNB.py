import naive_bayes

data,label,feature_set = naive_bayes.load_dataset()
model = naive_bayes.NB(15,2,feature_set)
model.train(data, label)
predict = model.predict([1,'L'])