import numpy as np

def load_dataset():
    data = [[1,'S'], [1,'M'], [1,'M'], [1,'S'], [1,'S'],[2,'S'],[2,'M'],[2,'M'],[2,'L'],[2,'L'],[3,'M'],[3,'M'],[3,'L'],[3,'L']]
    label = [0,0,1,1,0,0,0,1,1,1,1,1,1,1,0]
    feature_set = [[1,2,3],['S','M','L']]
    return data,label,feature_set

class NB:
    def __init__(self, sample_size, feature_size, feature_set):
        self.sample_size = sample_size
        self.feature_size = feature_size
        self.feature_set = feature_set

    def train(self, x, label):
        self.num_pos = sum(label)
        self.num_neg = self.sample_size - self.num_pos
        self.p_pos = self.num_pos / self.sample_size
        self.p_neg = 1 - self.p_pos
        self.count_pos = {}
        self.count_neg = {}
        for feature_i in self.feature_set:
            for feature in feature_i:
                self.count_pos[feature] = 0
                self.count_neg[feature] = 0

        for i in range(self.sample_size):
            if label[i] == 1:
                self.count_pos[x[i]] +=1
            else:
                self.count_pos[x[i]] +=1

        for feature_i in self.feature_set:
            for feature in feature_i:
                self.count_pos[feature] /= self.num_pos
                self.count_neg[feature] /= self.num_neg

    def predict(self, x):
        xp_pos = self.p_pos
        for feature in x:
            xp_pos *= self.count_pos[feature]
        xp_neg = self.p_neg
        for feature in x:
            xp_neg *= self.count_neg[feature]
        if xp_pos > xp_neg:
            return 1
        else:
            return 0