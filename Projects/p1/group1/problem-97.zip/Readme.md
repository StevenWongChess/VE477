This read me is for `aStarSearch.py`, which is an implementation of A* search algorithm, together with a priority queue and a graph data structure. Although A* can be applied to general path finding problem, as a demo, this program runs it on a traditional graph. The example graph is adapted from Figure 3.1 in *Artificial intelligence: a modern approach* by Russell, Stuart J. and Norvig, Peter and Davis, Ernest. 

Two kind of heuristics are offered. The first is a `nullHeuristic`, which always returns 0. Weird as this is, null heuristic is indeed admissible and consistent, but a bad one since it provides no directions. The other is `SLDHeuristic_b`. It is specially for cases where point `b` is the goal and simply gives the straight line distance from the current point to `b`. This the theoretically best heuristic (which is actually like a cheater as it is identical to the true value).

This code runs an A* search on `graph` looking for the shortest path from `a` to `b`, with the straight line distance heuristic to `b`. The default heuristic is `nullHeuristic`. It returns the path as a list.

```python
aStarSearch(graph, 'a', 'b', SLDHeuristic_b)
```

