import numpy as np
import heapq

alpha = "abcdefghilmnoprstuvz"

class PriorityQueue:

    def  __init__(self):
        self.heap = []
        self.count = 0

    def push(self, item, priority):
        entry = (priority, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1

    def pop(self):
        (_, _, item) = heapq.heappop(self.heap)
        return item

    def isEmpty(self):
        return self.count == 0


class Graph:
    def __init__(self, file):
        with open(file, 'r') as f:
            lines = f.readlines()
            self.n = int(lines[0])
            self.m = int(lines[1])
            self.adj = dict()
            for i in alpha:
                self.adj[i] = dict()
            for line in lines[2:]:
                nums = line.split(' ')
                self.adj[nums[0]][nums[1]] = int(nums[2])
                self.adj[nums[1]][nums[0]] = int(nums[2])

    def getNeighbours(self, node):
        neighbours = [(j, self.adj[node][j]) for j in self.adj[node].keys()]
        return neighbours


def nullHeuristic(graph, node):
    """
    A null heuristic which always returns 0
    """
    return 0

def SLDHeuristic_b(graph, node):
    """
    A heuristic which return the straight distance 
    between current node and node b (only works when goal is b)
    """
    sld = {'a' : 366, 'b' : 0, 'c' : 160, 'd' : 242, 'e' : 161,
           'f' : 176, 'g' : 77 , 'h' : 151, 'i' : 226, 'l' : 244,
           'm' : 241, 'n' : 234, 'o' : 380, 'p' : 100, 'r' : 193, 
           's' : 253, 't' : 329, 'u' : 80, 'v' : 199, 'z' : 374}
    return sld[node]

def aStarSearch(graph, start, goal, heuristic=nullHeuristic):
    closed = set()
    fringe = PriorityQueue()
    fringe.push((start, 0, [start]),
                 heuristic(graph, start))

    while not fringe.isEmpty():
        node, cost, path = fringe.pop()

        if node == goal:
            return path

        if node not in closed:
            closed.add(node) 
            for childNode, actionCost in graph.getNeighbours(node):
                if childNode not in closed:
                    fringe.push((childNode, cost + actionCost, path + [childNode]),
                                 cost + actionCost + heuristic(graph, childNode))
    return None

if __name__ == "__main__":
    graph = Graph("graph")
    path = aStarSearch(graph, 'a', 'b')
    path = aStarSearch(graph, 'a', 'b', SLDHeuristic_b)
    print(path)