import numpy as np
import scipy.special

class NN:
    def __init__(self, input, hidden, output, lr):
        self.input = input
        self.hidden = hidden
        self.output = output
        self.lr = lr

        self.w1 = np.random.normal(0.0, pow(self.input, -0.5), (self.hidden, self.input))
        self.w2 = np.random.normal(0.0, pow(self.hidden, -0.5), (self.output, self.hidden))

        self.activation_function = lambda x: scipy.special.expit(x)

    def forward(self):
        input_layer = np.array(self.input_layer, ndmin=2).T
        self.hidden_layer = self.activation_function(np.dot(self.w1, self.input_layer))
        self.output_layer = self.activation_function(np.dot(self.w2, self.hidden_layer))
        return self.hidden_layer, self.output_layer

    def back(self):
        output_error = self.target - self.output_layer
        hidden_error = np.dot(self.w2.T, output_error)

        self.w2 += self.lr * np.dot((output_error * self.output_layer * (1.0 - self.output_layer)),
                                    np.transpose(self.hidden_layer))
        self.w1 += self.lr * np.dot((hidden_error * self.hidden_layer * (1.0 - self.hidden_layer)),
                                    np.transpose(self.input_layer))

    def train(self, x, label):
        self.input_layer = np.array(x, ndmin=2).T
        self.target = np.array(label, ndmin=2).T
        self.forward()
        self.back()

