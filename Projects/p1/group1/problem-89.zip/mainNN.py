from neural_network import NN
import numpy as np

input = 784
hidden = 200
output = 10
learning_rate = 0.1
model = NN(input,hidden,output, learning_rate)

training_dataset_file = open("mnist_dataset/mnist_train.csv", 'r')
training_dataset_list = training_dataset_file.readlines()
training_dataset_file.close()
test_dataset_file = open("mnist_dataset/mnist_test.csv", 'r')
test_dataset_list = test_dataset_file.readlines()
test_dataset_file.close()

epochs = 5
for e in range(epochs):
    for record in training_dataset_list:
        data = record.split(',')
        input = (np.array(data[1:]).astype(np.float) / 255.0 * 0.99) + 0.01
        label = np.zeros(output) + 0.01
        label[int(data[0])] = 0.99
        model.train(input, label)

scorecard = []

for record in test_dataset_list:
    data = record.split(',')
    correct_label = int(data[0])
    input = (np.array(data[1:]).astype(float) / 255.0 * 0.99) + 0.01
    output = model.predict(input)
    label = np.argmax(output)
    if (label == correct_label):
        scorecard.append(1)
    else:
        scorecard.append(0)

print ("performance = ", sum(scorecard) / len(scorecard))