This readme is for file `bloom_demo.py`. The implementation is not for practical use but only offers visualized demonstration on how bloom filter works. 

An demonstrative Bloom filter class `BloomExample` is offered. The length of inner bit array can be costumed. To create a `BloomExample` with bit array 31, run

```python
bloom = BloomExample(31)
```

However, the number and type of hash functions are fixed. There are 2 hash functions, which are extremely simple and only for demonstration uses. `mod1` is modular by array length and `mod2` is modular by length after multiplied by 7. 

You can add and query elements in the filter by calling `bloom.add()` and `bloom.query()`. The explanations on the standard is given output is given below.

When adding a new element, 1024 for example, a typical output is

```bash
.O........O....O..............O
 *             *
add 1024
```

The first line is the bit array, with `.` for 0 and `O` for 1. The stars `*` on second rows corresponds to the hash results, which are newly set to be 1.

When query an existing element 1024, you may see something like

```bash
.O........O....O......O.......O
 *             *
1024 Exist with error rate 0.03
```

The stars matches the 1-bits in the array, so filter gives positive result. Besides, the false positive rate is also offered. On the other hand, if the element doesn't exist, there would be outputs like

```bash
.O........O....O......O.......O
* *
114514 Definitely not existing
```

Since there are hash results un-match the bit array, we are sure that the queried  element does not exist.

