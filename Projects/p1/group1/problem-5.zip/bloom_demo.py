import numpy as np



class BloomExample:
    def __init__(self, m):
        self.m = m
        self.array = [0] * self.m
        def mod1(x):
            return x % self.m
        def mod2(x):
            return (7*x) % 23
        self.hash = [mod1, mod2]
        self.count = 0

    def add(self, new):
        self.count += 1
        st = [' '] * self.m
        for fun in self.hash:
            self.array[fun(new)] = 1
            st[fun(new)] = '*'
        self.print_array()
        stt = ""
        for i in st:
            stt += i
        print(stt)
        print("add {}".format(new))
    
    def query(self, new):
        flag = 0
        st = [' '] * self.m
        for fun in self.hash:
            st[fun(new)] = '*'
            if not self.array[fun(new)]:
                flag = 1
        self.print_array()

        stt = ""
        for i in st:
            stt += i
        print(stt)
        
        if flag:
            print(new, "Definitely not existing")
        else:
            error = (1-2.718**(-2*self.count/self.m))**2
            print(new, "Exist with error rate {:.2f}".format(error, ))

    def print_array(self):
        print()
        print("=" * self.m)
        print()
        st = ""
        for i in self.array:
            st += "O" if i else "."
        print(st)


bloom = BloomExample(31)

bloom.print_array()

bloom.add(123)

bloom.query(123)

bloom.query(1024)

bloom.add(1024)

bloom.add(404)

bloom.query(1024)

bloom.query(114514)

bloom.query(2)